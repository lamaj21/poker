import express from 'express';
import http from 'http';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer } from 'ws';
import { Table } from './poker.js';

const { DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI, ADMIN_DISCORD_ID, NODE_ENV } = process.env;
const PORT = process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || './data.json';
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
if (![DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI, ADMIN_DISCORD_ID].every(Boolean)) {
  console.error('Set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI and ADMIN_DISCORD_ID.');
  process.exit(1);
}

// ---- storage (JSON file; swap for Postgres when scaling) ----
// Only minimal Discord data is stored: id, display name, avatar URL, join date.
const db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) : { users: {}, events: [] };
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

// ---- signed session cookie (HMAC-SHA256) ----
const hmac = v => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
const sign = v => `${v}.${hmac(v)}`;
function unsign(token) {
  const i = (token || '').lastIndexOf('.');
  if (i < 0) return null;
  const v = token.slice(0, i);
  const got = Buffer.from(token.slice(i + 1)), expect = Buffer.from(hmac(v));
  return got.length === expect.length && crypto.timingSafeEqual(got, expect) ? v : null;
}
const cookie = (req, name) =>
  (req.headers.cookie || '').split(';').map(c => c.trim()).find(c => c.startsWith(name + '='))?.slice(name.length + 1);

function sessionUser(req) {
  const raw = unsign(cookie(req, 'sid'));
  if (!raw) return null;
  const { uid, exp } = JSON.parse(Buffer.from(raw, 'base64url').toString());
  if (Date.now() > exp) return null;
  const u = db.users[uid];
  // Admin status is derived on the server from the env var. Never from client data.
  return u ? { ...u, isAdmin: uid === ADMIN_DISCORD_ID } : null;
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), 'public')));

const requireUser = (req, res, next) => {
  const u = sessionUser(req);
  if (!u) return res.status(401).json({ error: 'Login required' });
  req.user = u;
  next();
};
const requireAdmin = (req, res, next) =>
  requireUser(req, res, () => (req.user.isAdmin ? next() : res.status(403).json({ error: 'Admins only' })));

// ---- Discord OAuth2 (identify scope only) ----
app.get('/auth/discord', (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  res.setHeader('Set-Cookie', `oauth_state=${state}; HttpOnly; SameSite=Lax; Path=/; Max-Age=600`);
  res.redirect('https://discord.com/oauth2/authorize?' + new URLSearchParams({
    client_id: DISCORD_CLIENT_ID, redirect_uri: DISCORD_REDIRECT_URI, response_type: 'code', scope: 'identify', state,
  }));
});

app.get('/auth/discord/callback', async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!code || !state || state !== cookie(req, 'oauth_state')) return res.status(400).send('Invalid OAuth state');
    const tok = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: DISCORD_CLIENT_ID, client_secret: DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code', code, redirect_uri: DISCORD_REDIRECT_URI }),
    }).then(r => r.json());
    if (!tok.access_token) return res.status(400).send('Discord token exchange failed');
    const d = await fetch('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${tok.access_token}` },
    }).then(r => r.json());
    db.users[d.id] = {
      id: d.id,
      username: d.global_name || d.username,
      avatar: d.avatar ? `https://cdn.discordapp.com/avatars/${d.id}/${d.avatar}.png` : null,
      joinedAt: db.users[d.id]?.joinedAt || Date.now(),
    };
    save();
    const sid = sign(Buffer.from(JSON.stringify({ uid: d.id, exp: Date.now() + 7 * 864e5 })).toString('base64url'));
    res.setHeader('Set-Cookie', [
      `sid=${sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${NODE_ENV === 'production' ? '; Secure' : ''}`,
      'oauth_state=; Max-Age=0; Path=/',
    ]);
    res.redirect('/');
  } catch (e) {
    console.error(e);
    res.status(500).send('Login failed');
  }
});

app.post('/auth/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'sid=; Max-Age=0; Path=/; HttpOnly');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const u = sessionUser(req);
  res.json(u ? { id: u.id, username: u.username, avatar: u.avatar, isAdmin: u.isAdmin } : null);
});

// ---- events ----
const publicEvent = e => ({ id: e.id, title: e.title, description: e.description, startsAt: e.startsAt, format: e.format,
  startingStack: e.startingStack, maxPlayers: e.maxPlayers, status: e.status, registered: e.registrations.length });
const findEvent = (req, res) => {
  const e = db.events.find(x => x.id === req.params.id);
  if (!e) res.status(404).json({ error: 'Event not found' });
  return e;
};

app.get('/api/events', (req, res) => {
  const u = sessionUser(req);
  res.json(db.events.map(e => ({ ...publicEvent(e), joined: !!u && e.registrations.includes(u.id) })));
});

app.post('/api/events/:id/register', requireUser, (req, res) => {
  const e = findEvent(req, res);
  if (!e) return;
  if (e.status !== 'registration') return res.status(400).json({ error: 'Registration is closed' });
  if (e.registrations.includes(req.user.id)) return res.json({ ok: true });
  if (e.registrations.length >= e.maxPlayers) return res.status(400).json({ error: 'Event is full' });
  e.registrations.push(req.user.id);
  save();
  res.json({ ok: true });
});

app.delete('/api/events/:id/register', requireUser, (req, res) => {
  const e = findEvent(req, res);
  if (!e) return;
  if (e.status !== 'registration') return res.status(400).json({ error: 'Registration is closed' });
  e.registrations = e.registrations.filter(id => id !== req.user.id);
  save();
  res.json({ ok: true });
});

// ---- admin-only event management (server-enforced) ----
app.post('/api/admin/events', requireAdmin, (req, res) => {
  const { title, description = '', startsAt, format = "No-limit Hold'em", startingStack = 1000, maxPlayers = 9 } = req.body;
  if (!title || !startsAt || isNaN(Date.parse(startsAt))) return res.status(400).json({ error: 'title and valid startsAt required' });
  const e = { id: crypto.randomUUID(), title: String(title).slice(0, 80), description: String(description).slice(0, 1000),
    startsAt: new Date(startsAt).toISOString(), format: String(format).slice(0, 40), startingStack: +startingStack || 1000,
    maxPlayers: Math.min(90, +maxPlayers || 9), status: 'draft', registrations: [], createdBy: req.user.id };
  db.events.push(e);
  save();
  res.status(201).json(publicEvent(e));
});

const TRANS = { open: ['draft', 'closed'], close: ['registration'], start: ['registration', 'closed'],
  pause: ['live'], resume: ['paused'], end: ['live', 'paused'] };
const TO = { open: 'registration', close: 'closed', start: 'live', pause: 'paused', resume: 'live', end: 'completed' };
app.post('/api/admin/events/:id/status', requireAdmin, (req, res) => {
  const e = findEvent(req, res);
  if (!e) return;
  const a = req.body.action;
  if (!TRANS[a]?.includes(e.status)) return res.status(400).json({ error: `Cannot ${a} an event that is ${e.status}` });
  e.status = TO[a];
  save();
  res.json(publicEvent(e));
});

// Creates a table restricted to the event's registered players (or a supplied list).
app.post('/api/admin/events/:id/tables', requireAdmin, (req, res) => {
  const e = findEvent(req, res);
  if (!e) return;
  const t = makeTable({ sb: 10, bb: 20 });
  t.eventId = e.id;
  t.allowed = new Set(Array.isArray(req.body.userIds) && req.body.userIds.length ? req.body.userIds : e.registrations);
  res.status(201).json({ code: t.code });
});

// ---- tables ----
const tables = new Map();
const clients = new Map(); // table code -> Set of sockets

function makeTable(opts) {
  const code = crypto.randomBytes(4).toString('hex').toUpperCase();
  const t = new Table(code, { ...opts, onChange: tbl => broadcast(tbl) });
  tables.set(code, t);
  return t;
}

function broadcast(t) {
  for (const ws of clients.get(t.code) || []) {
    if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'state', state: t.view(ws.user.id) }));
  }
}

app.get('/api/tables', requireUser, (req, res) => {
  res.json([...tables.values()]
    .filter(t => !t.allowed || t.allowed.has(req.user.id) || req.user.isAdmin)
    .map(t => ({ code: t.code, players: t.players().length, street: t.street })));
});

app.post('/api/tables', requireUser, (req, res) => {
  res.status(201).json({ code: makeTable({ sb: 10, bb: 20 }).code });
});

app.get('/api/stats', (req, res) => {
  res.json({ online: [...clients.values()].reduce((n, s) => n + s.size, 0), tables: tables.size });
});

// ---- real-time channel ----
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (req, socket, head) => {
  const user = sessionUser(req);
  if (!user || !req.url.startsWith('/ws')) return socket.destroy();
  wss.handleUpgrade(req, socket, head, ws => {
    ws.user = user;
    wss.emit('connection', ws, req);
  });
});

wss.on('connection', (ws, req) => {
  const code = new URL(req.url, 'http://x').searchParams.get('table');
  const t = tables.get(code);
  if (!t || (t.allowed && !t.allowed.has(ws.user.id) && !ws.user.isAdmin)) return ws.close(4003, 'Not allowed');
  if (!clients.has(code)) clients.set(code, new Set());
  clients.get(code).add(ws);
  ws.send(JSON.stringify({ type: 'state', state: t.view(ws.user.id) }));

  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'sit') t.sit(ws.user, m.buyIn);
    else if (m.type === 'act') t.act(ws.user.id, m.action, m.amount);
    else if (m.type === 'leave') t.leave(ws.user.id);
  });
  ws.on('close', () => clients.get(code)?.delete(ws));
});

server.listen(PORT, () => console.log(`Velvet Room running on http://localhost:${PORT}`));
