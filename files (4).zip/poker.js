import crypto from 'crypto';

const RANKS = '23456789TJQKA';
const SUITS = 'shdc';
const CATS = ['High card', 'Pair', 'Two pair', 'Three of a kind', 'Straight', 'Flush', 'Full house', 'Four of a kind', 'Straight flush'];
const cardStr = c => RANKS[c.r] + SUITS[c.s];

export function newDeck() {
  const d = [];
  for (let r = 0; r < 13; r++) for (let s = 0; s < 4; s++) d.push({ r, s });
  for (let i = d.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}

function score5(cs) {
  const r = cs.map(c => c.r).sort((a, b) => b - a);
  const flush = cs.every(c => c.s === cs[0].s);
  const straight = new Set(r).size === 5 && (r[0] - r[4] === 4 || r.join() === '12,3,2,1,0');
  const high = straight ? (r[0] === 12 && r[1] === 3 ? 3 : r[0]) : -1;
  const cnt = {};
  r.forEach(x => (cnt[x] = (cnt[x] || 0) + 1));
  const g = Object.entries(cnt).map(([v, c]) => [c, +v]).sort((a, b) => b[0] - a[0] || b[1] - a[1]);
  let cat;
  if (straight && flush) cat = 8;
  else if (g[0][0] === 4) cat = 7;
  else if (g[0][0] === 3 && g[1][0] === 2) cat = 6;
  else if (flush) cat = 5;
  else if (straight) cat = 4;
  else if (g[0][0] === 3) cat = 3;
  else if (g[0][0] === 2) cat = g[1][0] === 2 ? 2 : 1;
  else cat = 0;
  const vals = straight ? [high] : g.map(x => x[1]);
  let v = cat;
  for (let i = 0; i < 5; i++) v = v * 13 + (vals[i] ?? 0);
  return v;
}

export function best7(cs) {
  let best = -1;
  for (let a = 0; a < cs.length; a++)
    for (let b = a + 1; b < cs.length; b++) {
      const s = score5(cs.filter((_, i) => i !== a && i !== b));
      if (s > best) best = s;
    }
  return best;
}

export class Table {
  constructor(code, { sb = 10, bb = 20, onChange = () => {} } = {}) {
    Object.assign(this, { code, sb, bb, onChange, seats: [], board: [], street: 'waiting', dealer: -1, toAct: -1,
      currentBet: 0, lastRaise: bb, showdown: null, result: 'Waiting for players', deck: [] });
  }

  emit() { this.onChange(this); }
  players() { return this.seats.filter(Boolean); }
  canAct(i) { const s = this.seats[i]; return !!s && s.inHand && !s.folded && !s.allIn; }
  live() { return this.seats.map((s, i) => (s && s.inHand && !s.folded ? i : -1)).filter(i => i >= 0); }

  nextIdx(from) {
    const n = this.seats.length;
    for (let k = 1; k <= n; k++) { const j = (from + k) % n; if (this.canAct(j)) return j; }
    return -1;
  }

  nextToAct(from) {
    const n = this.seats.length;
    for (let k = 1; k <= n; k++) {
      const j = (from + k) % n;
      const s = this.seats[j];
      if (this.canAct(j) && (!s.acted || s.bet < this.currentBet)) return j;
    }
    return -1;
  }

  sit(user, buyIn) {
    if (this.seats.some(s => s && s.id === user.id)) return;
    let idx = this.seats.findIndex(s => !s);
    if (idx < 0) { if (this.seats.length >= 9) return; idx = this.seats.length; }
    this.seats[idx] = { id: user.id, name: user.username, avatar: user.avatar, stack: Math.min(10000, Math.max(100, +buyIn || 1000)),
      hand: [], bet: 0, total: 0, inHand: false, folded: false, allIn: false, acted: false };
    if (this.street === 'waiting' && this.players().length >= 2) this.startHand();
    else this.emit();
  }

  leave(id) {
    const i = this.seats.findIndex(s => s && s.id === id);
    if (i < 0) return;
    const s = this.seats[i];
    if (s.inHand && !s.folded && this.street !== 'waiting' && this.street !== 'showdown') {
      s.leaving = true;
      s.folded = true;
      this.afterAction(i);
    } else this.seats[i] = null;
    this.emit();
  }

  post(i, amt) {
    const s = this.seats[i];
    const x = Math.min(amt, s.stack);
    s.stack -= x; s.bet += x; s.total += x;
    if (s.stack === 0) s.allIn = true;
  }

  startHand() {
    this.seats = this.seats.map(s => (s && !s.leaving && s.stack > 0 ? s : null));
    const ready = this.seats.map((s, i) => (s ? i : -1)).filter(i => i >= 0);
    if (ready.length < 2) { this.street = 'waiting'; this.result = 'Need at least 2 players with chips'; return this.emit(); }
    this.deck = newDeck();
    this.board = [];
    this.showdown = null;
    this.result = '';
    this.seats.forEach(s => s && Object.assign(s, { hand: [], bet: 0, total: 0, inHand: true, folded: false, allIn: false, acted: false }));
    const after = ready.filter(i => i > this.dealer);
    this.dealer = after.length ? after[0] : ready[0];
    const sb = ready.length === 2 ? this.dealer : this.nextIdx(this.dealer);
    const bb = this.nextIdx(sb);
    this.post(sb, this.sb);
    this.post(bb, this.bb);
    this.currentBet = Math.max(...this.seats.map(s => (s ? s.bet : 0)));
    this.lastRaise = this.bb;
    for (let r = 0; r < 2; r++) ready.forEach(i => this.seats[i].hand.push(this.deck.pop()));
    this.street = 'preflop';
    this.toAct = this.nextToAct(bb);
    this.emit();
    if (this.toAct < 0) this.nextStreet();
  }

  act(id, action, amount = 0) {
    const i = this.seats.findIndex(s => s && s.id === id);
    if (['waiting', 'showdown'].includes(this.street) || i < 0 || i !== this.toAct) return;
    const s = this.seats[i];
    const toCall = this.currentBet - s.bet;
    if (action === 'fold') s.folded = true;
    else if (action === 'check') { if (toCall > 0) return; }
    else if (action === 'call') { if (toCall <= 0) return; this.post(i, toCall); }
    else if (action === 'raise' || action === 'allin') {
      const max = s.bet + s.stack;
      const to = action === 'allin' ? max : Math.min(Math.floor(+amount || 0), max);
      if (to < max && to < this.currentBet + this.lastRaise) return;
      this.post(i, to - s.bet);
      const inc = to - this.currentBet;
      if (inc > 0) {
        if (inc >= this.lastRaise) {
          this.lastRaise = inc;
          this.seats.forEach((x, j) => { if (x && j !== i) x.acted = false; });
        }
        this.currentBet = to;
      }
    } else return;
    s.acted = true;
    this.afterAction(i);
  }

  afterAction(i) {
    if (this.live().length <= 1) return this.settle(false);
    if (this.roundOver()) return this.nextStreet();
    if (i === this.toAct) this.toAct = this.nextToAct(i);
    this.emit();
  }

  roundOver() {
    return this.live().every(i => { const s = this.seats[i]; return s.allIn || (s.acted && s.bet === this.currentBet); });
  }

  nextStreet() {
    this.seats.forEach(s => s && Object.assign(s, { bet: 0, acted: false }));
    this.currentBet = 0;
    this.lastRaise = this.bb;
    const next = { preflop: 'flop', flop: 'turn', turn: 'river' }[this.street];
    if (!next) return this.settle(true);
    this.board.push(...(next === 'flop' ? [this.deck.pop(), this.deck.pop(), this.deck.pop()] : [this.deck.pop()]));
    this.street = next;
    if (this.live().filter(i => this.canAct(i)).length < 2) return this.nextStreet();
    this.toAct = this.nextToAct(this.dealer);
    this.emit();
  }

  settle(reveal) {
    const live = this.live();
    const score = {};
    if (reveal) live.forEach(i => (score[i] = best7([...this.seats[i].hand, ...this.board])));

    // Build side pots from contribution levels.
    const rem = this.seats.map(s => (s ? s.total : 0));
    const pots = [];
    for (;;) {
      const pos = rem.filter(x => x > 0);
      if (!pos.length) break;
      const lvl = Math.min(...pos);
      let amt = 0;
      rem.forEach((r, i) => { if (r > 0) { amt += Math.min(r, lvl); rem[i] = r - Math.min(r, lvl); } });
      let elig = live.filter(i => this.seats[i].total >= lvl);
      if (!elig.length) elig = live;
      pots.push({ amt, elig });
    }

    const winners = [];
    pots.forEach(p => {
      let w = p.elig;
      if (reveal) { const top = Math.max(...w.map(i => score[i])); w = w.filter(i => score[i] === top); }
      const share = Math.floor(p.amt / w.length);
      w.forEach(i => { this.seats[i].stack += share; if (!winners.includes(i)) winners.push(i); });
      this.seats[w[0]].stack += p.amt - share * w.length;
    });

    this.showdown = reveal ? live.map(i => ({ seat: i, name: CATS[Math.floor(score[i] / 371293)] })) : null;
    this.result = `${winners.map(i => this.seats[i].name).join(', ')} wins the pot`;
    this.seats.forEach(s => s && Object.assign(s, { bet: 0, total: 0 }));
    this.toAct = -1;
    this.street = 'showdown';
    this.seats = this.seats.map(s => (s && s.leaving ? null : s));
    this.emit();
    setTimeout(() => this.startHand(), 6000);
  }

  view(uid) {
    const reveal = this.street === 'showdown';
    return {
      code: this.code, street: this.street, board: this.board.map(cardStr),
      pot: this.seats.reduce((a, s) => a + (s ? s.total : 0), 0),
      dealer: this.dealer, toAct: this.toAct, currentBet: this.currentBet, sb: this.sb, bb: this.bb,
      result: this.result, showdown: this.showdown,
      seats: this.seats.map((s, i) => (s ? {
        i, id: s.id, name: s.name, avatar: s.avatar, stack: s.stack, bet: s.bet,
        folded: s.folded, allIn: s.allIn, inHand: s.inHand,
        cards: s.id === uid || (reveal && this.showdown?.some(x => x.seat === i))
          ? s.hand.map(cardStr)
          : s.hand.length ? ['?', '?'] : [],
      } : null)),
    };
  }
}
